package com.example.shubhangi.homepage;


import android.support.v7.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity
{
}
