package com.example.shubhangi.homepage;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login_second extends AppCompatActivity implements View.OnClickListener {
    EditText username,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_second);
        Bundle obj= getIntent().getExtras();

        String str1= obj.getString(Login.key);


        username=(EditText) findViewById(R.id.username);
        password=(EditText) findViewById(R.id.password);
        Button login=(Button) findViewById(R.id.login);
        login.setOnClickListener(this);
    }



    @Override
    public void onClick(View view)
    {
        if(isempty())
        {

        }
    }

    private boolean isempty() {

        if(username.getText().toString().length()<=0||password.getText().toString().length()<=0) {

            Toast.makeText(this,"ENTER USERNAME AND PASSWORD",Toast.LENGTH_LONG).show();
            return true;
        }
        else
        {
            Toast.makeText(this,"Homepage",Toast.LENGTH_LONG).show();
            Intent i=new Intent(this,main2.class);
            startActivity(i);
            return true;
        }

    }
}