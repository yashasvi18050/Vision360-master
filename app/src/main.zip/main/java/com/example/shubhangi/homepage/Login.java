package com.example.shubhangi.homepage;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class Login extends AppCompatActivity {

    public static final String key = "user";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_main);
        Button admin = findViewById(R.id.ADMIN);

        admin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String user = "ADMIN";
                Intent intent = new Intent(Login.this, login_second.class);
                intent.putExtra(key, user);
                startActivity(intent);
            }


        });


        Button student = (Button) findViewById(R.id.STUDENT);
        student.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String user = "STUDENT";

                Intent intent = new Intent(Login.this, login_second.class);
                intent.putExtra(key, user);
                startActivity(intent);
            }

        });
    }

}
